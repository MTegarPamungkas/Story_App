package com.tegar.submissionaplikasistoryapp.ui

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import com.tegar.submissionaplikasistoryapp.data.local.UserDataStore
import com.tegar.submissionaplikasistoryapp.databinding.ActivitySplashScreenBinding
import kotlinx.coroutines.launch

@SuppressLint("CustomSplashScreen")
class SplashScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySplashScreenBinding
    private lateinit var userDataStore: UserDataStore
    private var animationComplete = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        userDataStore = UserDataStore.getInstance(this)

        binding.SplashScreenImage.alpha = 0f
        binding.SplashScreenImage.animate().setDuration(1500).alpha(1f).withEndAction {
            if (animationComplete) {
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            } else {
                animationComplete = true

                lifecycleScope.launch {
                    var intent: Intent
                    userDataStore.getUserData().collect { data ->
                        intent = if (data.userId.isNotEmpty() && data.name.isNotEmpty() && data.token.isNotEmpty()) {
                            Intent(this@SplashScreen, MainActivity::class.java)
                        } else {
                            Intent(this@SplashScreen, StartActivity::class.java)
                        }
                        startActivity(intent)
                        finish()
                    }
                }
            }
        }
    }
}
