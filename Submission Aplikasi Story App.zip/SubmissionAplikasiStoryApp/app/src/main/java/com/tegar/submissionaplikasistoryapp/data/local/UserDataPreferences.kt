package com.tegar.submissionaplikasistoryapp.data.local

data class UserDataPreferences(
    val userId: String,
    val name: String,
    val token: String
)