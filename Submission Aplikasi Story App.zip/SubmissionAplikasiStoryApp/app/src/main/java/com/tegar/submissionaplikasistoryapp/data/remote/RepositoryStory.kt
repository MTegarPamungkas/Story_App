package com.tegar.submissionaplikasistoryapp.data.remote

import com.google.gson.Gson
import com.tegar.submissionaplikasistoryapp.data.remote.response.ErrorResponse
import com.tegar.submissionaplikasistoryapp.data.remote.retrofit.ApiService
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.HttpException
import java.io.File
import java.io.IOException
import androidx.lifecycle.liveData
import okhttp3.RequestBody.Companion.toRequestBody

class RepositoryStory(private val apiService: ApiService) {
     fun register(name: String, email: String, password: String) = liveData {
        try {
            emit(ResultMessage.Loading)
            val response = apiService.register(name, email, password)
            emit(ResultMessage.Success(response))
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody?.message
            emit(ResultMessage.Error(Exception(errorMessage)))
        } catch (e: IOException) {
            emit(ResultMessage.Error(Exception("No network connection")))
        }
    }

    fun login(email: String, password: String) = liveData {
         try {
            emit(ResultMessage.Loading)
            val response = apiService.login(email, password)
            emit(ResultMessage.Success(response))
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody?.message
            emit(ResultMessage.Error(Exception(errorMessage)))
        } catch (e: IOException) {
            emit(ResultMessage.Error(Exception("No network connection")))
        }
    }

    fun getAllStories() = liveData {
        try {
            emit(ResultMessage.Loading)
            val response = apiService.getAllStories()
            emit(ResultMessage.Success(response))
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody?.message
            emit(ResultMessage.Error(Exception(errorMessage)))
        }  catch (e: IOException) {
            emit(ResultMessage.Error(Exception("No network connection")))
        }
    }

     fun newPost(description: String, photo: File, lat: Float?, lon: Float?) = liveData {
        val requestImageFile = photo.asRequestBody("image/jpeg".toMediaType())
        val requestBody = description.toRequestBody("text/plain".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "photo",
            photo.name,
            requestImageFile
        )
        try {
            emit(ResultMessage.Loading)
            val response = apiService.postStory(requestBody, multipartBody, lat, lon)
            emit(ResultMessage.Success(response))
        } catch (e: HttpException) {
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody?.message
            emit(ResultMessage.Error(Exception(errorMessage)))
        } catch (e: IOException) {
            emit(ResultMessage.Error(Exception("No network connection")))
        }
    }

    companion object {
        @Volatile
        private var instance: RepositoryStory? = null
        fun getInstance(
            apiService: ApiService,
        ): RepositoryStory =
            instance ?: synchronized(this) {
                instance ?: RepositoryStory(apiService)
            }.also { instance = it }
    }
}
