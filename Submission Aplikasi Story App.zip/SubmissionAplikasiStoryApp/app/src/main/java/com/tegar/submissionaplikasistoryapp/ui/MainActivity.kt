package com.tegar.submissionaplikasistoryapp.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.tegar.submissionaplikasistoryapp.R
import com.tegar.submissionaplikasistoryapp.data.local.UserDataStore
import com.tegar.submissionaplikasistoryapp.data.remote.ResultMessage
import com.tegar.submissionaplikasistoryapp.data.remote.response.ListStoryItem
import com.tegar.submissionaplikasistoryapp.data.remote.response.ResponseGetAll
import com.tegar.submissionaplikasistoryapp.databinding.ActivityMainBinding
import com.tegar.submissionaplikasistoryapp.ui.adapter.AdapterListStories
import com.tegar.submissionaplikasistoryapp.ui.viewmodel.MainViewModel
import com.tegar.submissionaplikasistoryapp.ui.viewmodel.MainViewModelFactory
import com.tegar.submissionaplikasistoryapp.util.ToastUtils
import kotlinx.coroutines.launch
import android.provider.Settings
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var userDataStore: UserDataStore
    private val mainViewModel: MainViewModel by viewModels {
        MainViewModelFactory.getInstance(this)
    }

    private val addStoryResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val storyAdded = data?.getBooleanExtra("story_added", false) ?: false
            if (storyAdded) {
                mainViewModel.getAllStories().observe(this) {
                    handleResult(it)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        userDataStore = UserDataStore.getInstance(this)
        binding.btnAdd.setOnClickListener(this)
        mainViewModel.getAllStories().observe(this) { result ->
            handleResult(result)
        }
    }

    @SuppressLint("DiscouragedApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.item_menu, menu)
        supportActionBar?.title = getString(R.string.story_sync)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.setting -> openSetting()
            R.id.logout -> logout()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_add -> openAddStoryActivity()
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun setRecyclerView(data: List<ListStoryItem?>?) {
        binding.rvStories.setHasFixedSize(true)
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            binding.rvStories.layoutManager = GridLayoutManager(this, 2)
        } else {
            binding.rvStories.layoutManager = LinearLayoutManager(this)
        }
        val adapter = AdapterListStories(data as List<ListStoryItem>)
        binding.rvStories.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun handleResult(result: ResultMessage<ResponseGetAll>) {
        when (result) {
            is ResultMessage.Loading -> {
                showLoading(true)
            }
            is ResultMessage.Success -> {
                val stories = result.data
                if (stories.listStory.isNullOrEmpty()) {
                    ToastUtils.showToast(this, getString(R.string.empty_story))
                } else {
                    setRecyclerView(stories.listStory)
                }
                showLoading(false)
            }
            is ResultMessage.Error -> {
                val exception = result.exception
                val errorMessage = exception.message ?: getString(R.string.an_error_occurred_while_fetching_data)
                ToastUtils.showToast(this, errorMessage)
                showLoading(false)
            }
        }
    }

    private fun openAddStoryActivity() {
        val intent = Intent(this, AddStoryActivity::class.java)
        addStoryResultLauncher.launch(intent)
    }

    private fun openSetting() {
        val intent = Intent(Settings.ACTION_LOCALE_SETTINGS)
        startActivity(intent)
    }

    private fun logout() {
        val builder = AlertDialog.Builder(this@MainActivity)
        builder.setTitle(getString(R.string.confirm_logout))
        builder.setMessage(getString(R.string.are_you_sure_you_want_to_logout))
        builder.setPositiveButton(getString(R.string.yes)) { _, _ ->
            lifecycleScope.launch {
                userDataStore.deleteSession()
                MainViewModelFactory.clearInstance()
                val intent = Intent(this@MainActivity, StartActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
        builder.setNegativeButton(getString(R.string.no)) { _, _ ->
        }

        val dialog = builder.create()
        dialog.show()

    }
}
