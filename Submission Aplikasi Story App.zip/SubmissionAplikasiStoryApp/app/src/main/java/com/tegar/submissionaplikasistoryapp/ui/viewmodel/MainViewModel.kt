package com.tegar.submissionaplikasistoryapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.tegar.submissionaplikasistoryapp.data.remote.RepositoryStory

class MainViewModel(private val repositoryStory: RepositoryStory) : ViewModel() {

    init {
        getAllStories()
    }
    fun getAllStories() = repositoryStory.getAllStories()

}