package com.tegar.submissionaplikasistoryapp.data.remote

import android.content.Context
import com.tegar.submissionaplikasistoryapp.data.local.UserDataStore
import com.tegar.submissionaplikasistoryapp.data.remote.retrofit.ApiConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Injection {
    fun provideRepository(context: Context): RepositoryStory {
        val pref = UserDataStore.getInstance(context)
        val user = runBlocking { pref.getUserData().first() }
        val apiService = ApiConfig.getApiService(user.token)
        return RepositoryStory(apiService)
    }
}