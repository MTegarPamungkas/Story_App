package com.tegar.submissionaplikasistoryapp.util

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object DateUtils {
    fun formatDate(dateString: String): String? {
        return try {
            val inputDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
            inputDateFormat.timeZone = TimeZone.getTimeZone("UTC")

            val outputDateFormat = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale.getDefault())
            outputDateFormat.timeZone = TimeZone.getDefault()

            val date = inputDateFormat.parse(dateString)
            date?.let { outputDateFormat.format(it) }

        } catch (e: Exception) {
            e.printStackTrace()
            dateString
        }
    }
}