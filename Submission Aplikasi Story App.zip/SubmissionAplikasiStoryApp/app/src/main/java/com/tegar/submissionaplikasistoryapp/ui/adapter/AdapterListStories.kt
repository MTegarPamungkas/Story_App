package com.tegar.submissionaplikasistoryapp.ui.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.tegar.submissionaplikasistoryapp.data.remote.response.ListStoryItem
import com.tegar.submissionaplikasistoryapp.data.remote.response.ResponseGetAll
import com.tegar.submissionaplikasistoryapp.databinding.ItemStoriesBinding
import com.tegar.submissionaplikasistoryapp.ui.DetailStory
import com.tegar.submissionaplikasistoryapp.util.DateUtils
import com.tegar.submissionaplikasistoryapp.util.formatFirstChar

class AdapterListStories(private val listStories: List<ListStoryItem>) : ListAdapter<ResponseGetAll, AdapterListStories.ViewHolder>(DIFF_CALLBACK){
    class ViewHolder(private val binding : ItemStoriesBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(data: ListStoryItem) {
            binding.itemName.text = data.name.formatFirstChar()
            binding.itemDesc.text = data.description.formatFirstChar()
            binding.itemCreated.text = DateUtils.formatDate(data.createdAt.toString())
            Glide.with(itemView.context)
                .load(data.photoUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(binding.itemPhoto)

            itemView.setOnClickListener{
                val intent = Intent(itemView.context, DetailStory::class.java)
                intent.putExtra(DetailStory.EXTRA_DATA, data)

                val optionsCompat: ActivityOptionsCompat =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        itemView.context as Activity,
                        Pair(binding.itemCardProfile, "profile"),
                        Pair(binding.itemName, "nama"),
                        Pair(binding.itemCreated, "created"),
                        Pair(binding.itemDesc, "description"),
                        Pair(binding.itemCardPhoto, "image"),
                    )
                itemView.context.startActivity(intent, optionsCompat.toBundle())
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemStoriesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listStories[position])
    }

    override fun getItemCount(): Int = listStories.size

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ResponseGetAll>() {
            override fun areItemsTheSame(oldItem: ResponseGetAll, newItem: ResponseGetAll): Boolean {
                return oldItem == newItem
            }
            override fun areContentsTheSame(oldItem: ResponseGetAll, newItem: ResponseGetAll): Boolean {
                return oldItem == newItem
            }
        }
    }
}